# Wackyplot

This is a plot helping library that I found particularly useful when writing scientific papers with multiple figures.

The idea is to keep plot styles consistent (e.g., figure sizes, legends, axes,file formats).