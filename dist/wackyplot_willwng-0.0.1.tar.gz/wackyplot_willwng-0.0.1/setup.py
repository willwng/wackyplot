from setuptools import find_packages, setup

setup(
    name="wackyplot",
    packages=find_packages(["wackyplot"]),
    version="1.0.0",
    description="Plotting Helper Package",
    author="willwng",
)
